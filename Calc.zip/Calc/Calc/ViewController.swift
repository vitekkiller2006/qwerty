//
//  ViewController.swift
//  Calc
//
//  Created by Admin on 30.03.2022.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var buttonAC: UIButton!
    @IBOutlet weak var buttonZero: UIButton!
    @IBOutlet weak var resultLabel: UILabel!
    
    @IBOutlet weak var buttonOne: UIButton!
    
    @IBOutlet weak var buttonTwo: UIButton!
    
    @IBOutlet weak var buutonThree: UIButton!
    
    @IBOutlet weak var buttonFour: UIButton!
    
    @IBOutlet weak var buttonFive: UIButton!
    
    @IBOutlet weak var buttonSix: UIButton!
    
    @IBOutlet weak var buttonSeven: UIButton!
    
    @IBOutlet weak var buttonEight: UIButton!
    
    @IBOutlet weak var buttonNine: UIButton!
    
    @IBOutlet weak var buttonRavno: UIButton!
    
    @IBOutlet weak var buttonPlus: UIButton!
    
    @IBOutlet weak var buttonMinus: UIButton!
    
    @IBOutlet weak var buttonUmnozhit: UIButton!
    
    @IBOutlet weak var buttonRazdelit: UIButton!
    
    var numberOne = ""
    var numberTwo = ""
    var operand = ""
    
    //нажитие цифр
    @IBAction func funcinputNumber(_ sender: UIButton) {
        
        if operand.isEmpty {
            numberOne = numberOne + (sender.titleLabel?.text)!
            resultLabel.text = numberOne
        } else {
            numberTwo = numberTwo + (sender.titleLabel?.text)!
            resultLabel.text = numberTwo
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        buttonAC.layer.cornerRadius = 36

        // Do any additional setup after loading the view.
    }


}

